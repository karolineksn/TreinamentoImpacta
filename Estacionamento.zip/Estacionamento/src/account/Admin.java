package account;
import model.parking.Entrance;
import model.parking.Exit;
import model.parking.ParkingSpot;
import panel.DisplayBoard;

public class Admin extends Account {

    @Override
    public boolean resetPassword() {
        return false;
    }

    public boolean addParkingSpot(ParkingSpot spot) {
        return true;
    }

    public boolean addDisplayBoard(DisplayBoard displayBoard) {
        return true;
    }

    public boolean addEntrance(Entrance entrance){
        return true;
    }

    public boolean exit(Exit exit){
        return true;
    }
}
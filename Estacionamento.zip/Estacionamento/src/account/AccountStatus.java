package account;

public enum AccountStatus {

    Active,
    Closed,
    Canceled,
    Blacklist,
    None,
}
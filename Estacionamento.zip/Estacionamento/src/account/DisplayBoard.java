package account;
import model.parking.MotorCycle;
import model.parking.Compact;
import model.parking.Handicapped;
import model.parking.Large;

import java.util.List;

public class DisplayBoard {

    private int id;
    private List<Handicapped> handicappedSpot;
    private List<Large> largeSpot;
    private List<Compact> compactSpot;
    private List<MotorCycle> motorCycleSpot;

    public void showFreeSlot(){

    }

    public boolean exit(String exit){
        return true;
    }
}
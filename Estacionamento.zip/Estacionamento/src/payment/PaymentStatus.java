package payment;

public enum PaymentStatus {

    Completed,
    Failed,
    Pending,
    Unpaid,
    Refunded
}
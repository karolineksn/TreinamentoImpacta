package payment;

public class Cash extends Payment{

}
package payment;

public class CardReader {
    void insertCard(){

    }

    void ejectCard(){

    }
}

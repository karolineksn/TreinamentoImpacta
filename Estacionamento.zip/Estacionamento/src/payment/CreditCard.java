package payment;

public class CreditCard extends Payment{

}
package model.parking;

public class Handicapped  extends ParkingSpot{

}
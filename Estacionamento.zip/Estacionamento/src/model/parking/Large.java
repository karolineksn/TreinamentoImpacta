package model.parking;

public class Large extends ParkingSpot{

}
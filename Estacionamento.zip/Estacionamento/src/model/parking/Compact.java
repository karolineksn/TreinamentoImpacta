package model.parking;

public class Compact extends ParkingSpot{
}
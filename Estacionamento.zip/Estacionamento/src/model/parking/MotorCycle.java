package model.parking;

public class MotorCycle extends ParkingSpot{
}
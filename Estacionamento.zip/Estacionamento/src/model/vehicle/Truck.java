package model.vehicle;
import model.parking.ParkingTicket;

public class Truck extends Vehicle{
    @Override
    public void assingTicket(ParkingTicket parkingTicket) {

    }
}
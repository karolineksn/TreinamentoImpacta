package model.vehicle;
import model.parking.ParkingTicket;

public class Van extends Vehicle{
    @Override
    public void assingTicket(ParkingTicket parkingTicket) {

    }
}
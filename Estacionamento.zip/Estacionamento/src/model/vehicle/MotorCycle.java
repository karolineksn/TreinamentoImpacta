package model.vehicle;
import model.parking.ParkingTicket;

public class MotorCycle extends Vehicle{
    @Override
    public void assingTicket(ParkingTicket parkingTicket) {

    }
}
package panel;

public class ExitPanel {
    void requestReceipt(){

    }
}
